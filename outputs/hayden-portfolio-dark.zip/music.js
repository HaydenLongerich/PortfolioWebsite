(() => {
const START=40;
const audio=new Audio('assets/background-music.mp3');audio.preload='auto';audio.volume=.28;audio.loop=false;audio.muted=false;
// Each page opening starts fresh at 0:40, with sound requested by default.
let muted=false,positioned=false,blocked=false,failed=false;
const button=document.createElement('button');button.type='button';button.className='music-toggle';button.innerHTML='<span class="music-bars" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span><span class="music-tooltip" aria-hidden="true"></span>';document.body.append(button);
const tip=button.querySelector('.music-tooltip');
function update(){const sounding=positioned&&!audio.paused&&!audio.muted&&!audio.ended;button.classList.toggle('is-playing',sounding);button.classList.toggle('is-muted',muted);button.setAttribute('aria-pressed',String(sounding));const label=muted?'Unmute background music':blocked?'Play background music':'Mute background music';button.setAttribute('aria-label',label);button.title=label;tip.textContent=muted?'Sound off':blocked?'Click to enable sound':sounding?'Sound on':'Starting at 0:40'}
async function play(){if(muted||!positioned||failed)return;try{await audio.play();blocked=false}catch(error){blocked=true}update()}
function seekStart(){positioned=false;audio.pause();audio.currentTime=START;update()}
audio.addEventListener('loadedmetadata',()=>{if(!Number.isFinite(audio.duration)||audio.duration<=START){fail();return}seekStart()});
// Do not play on loadedmetadata: the seek must actually finish first.
audio.addEventListener('seeked',()=>{if(Math.abs(audio.currentTime-START)>.5)return;positioned=true;play();update()});
audio.addEventListener('ended',seekStart);
for(const event of ['play','pause','volumechange'])audio.addEventListener(event,update);
function fail(){failed=true;button.disabled=true;button.classList.remove('is-playing');button.setAttribute('aria-label','Background music unavailable');tip.textContent='Audio unavailable'}
audio.addEventListener('error',fail);
button.addEventListener('click',()=>{if(blocked&&!muted){play();return}muted=!muted;audio.muted=muted;if(!muted)play();update()});
function unlock(e){if(e.target.closest?.('.music-toggle')||muted||!audio.paused)return;play()}
document.addEventListener('click',unlock);document.addEventListener('keydown',e=>{if(e.key!=='Tab'&&!e.repeat)unlock(e)});
document.addEventListener('visibilitychange',()=>button.classList.toggle('is-hidden-tab',document.hidden));
update();audio.load();
})();
